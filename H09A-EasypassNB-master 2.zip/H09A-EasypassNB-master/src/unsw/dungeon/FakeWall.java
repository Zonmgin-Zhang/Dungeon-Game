package unsw.dungeon;

public class FakeWall extends Entity{

    public FakeWall(int x, int y) {
        super(x, y);
    }

}
