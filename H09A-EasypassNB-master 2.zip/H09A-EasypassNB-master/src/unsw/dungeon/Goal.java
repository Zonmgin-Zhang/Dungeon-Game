package unsw.dungeon;

public interface Goal {
    public Boolean checkStatus();
}